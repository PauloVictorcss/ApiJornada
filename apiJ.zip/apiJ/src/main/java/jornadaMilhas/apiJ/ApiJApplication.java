package jornadaMilhas.apiJ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiJApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiJApplication.class, args);
	}

}
